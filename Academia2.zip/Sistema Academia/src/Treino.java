/**
 * Created by Marcel Fernandes on 6/2/2017.
 */
public class Treino{
	String[] exs_imp;
    Exercicio[] exercicios;
    char c;

    public Treino(char c, Exercicio[] exercicios){
        this.exercicios = exercicios;
        this.c = c;
    }
    
    public String[] imprimirExs(){
    	for(int i = 0; i< exercicios.length; i++){
    		 exs_imp[i] = exercicios[i].imprimir();
    	}
    return exs_imp;	
    }
 }