
public class Exercicio {
 	private String nome;
 	private int series;
	private int repeticoes;

	public Exercicio(String nome, int series, int repeticoes) {
		this.nome = nome;
		this.series = series;
		this.repeticoes = repeticoes;
	}

	public String imprimir() {
		//System.out.println("Exercicio: " + nome + " Series: " + series + " Rep: " + repeticoes);
		
		String s= "Exercicio: " + nome + " Series: " + series + " Rep: " + repeticoes;
		return s;
	}
		
}