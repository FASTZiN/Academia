
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class Aluno { // implements ActionListener {
    //private String[] lista;
    //private Exercicio[] exercicios = new Exercicio[6];
    //private int n;
    //JLabel r;
	/*Aluno(JLabel r){
	this.r = r;	
	}*/

    Treino[] treinos;
    String nome;
    String matriculaAluno;

    public Aluno(Treino[] treinos, String nome, String matriculaAluno) {
        this.treinos = treinos;
        this.nome = nome;
        this.matriculaAluno = matriculaAluno;
    }

   /* public String[] getTreino(int i){
       return treinos[i].imprimirExs();
    }*/
    
    public void getTreino(int i, JTextArea textArea){
    	for(String W: treinos[i].imprimirExs())
    		  textArea.append(W);
        //return treinos[i].imprimirExs();
     }

    
    public String[] getTreino(int i){
        return treinos[i].imprimirExs();
     }


    public void setTreino(int i, Treino t){
        this.treinos[i] = t;
    }

    public void setTreinos(Treino[] treinos) {
        this.treinos = treinos;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setMatriculaAluno(String matriculaAluno) {
        this.matriculaAluno = matriculaAluno;
    }
}

