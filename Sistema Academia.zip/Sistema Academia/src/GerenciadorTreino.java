import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JTextArea;

public interface GerenciadorTreino {
	
	void imprimirTreino(Exercicio[] exercicios);
	
	
}
