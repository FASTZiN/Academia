
public class imprimirSystemOut implements GerenciadorExs{
	public void imprimirExs(String nome, String serie, String repeticao) {
		System.out.println("Exercicio: " + nome + "\nSeries: " + serie + "\nReps: " + repeticao + "\n################");
	}

}
