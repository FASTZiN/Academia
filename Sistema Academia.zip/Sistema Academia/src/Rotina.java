/**
 * Created by Marcel Fernandes on 6/3/2017.
 */
public class Rotina {
    Treino[] treinos;
    char c;

    public Rotina(char c, Treino[] treinos){
        this.treinos = treinos;
        this.c = c;
    }
}
