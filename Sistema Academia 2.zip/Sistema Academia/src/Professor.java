import java.util.Arrays;
import java.util.Random;

import javax.swing.*;

public class Professor {
	private int mat_selecionada;
	Aluno[] alunos = new Aluno[90000000];
    private int n;
    private Aluno x;
	private int qtsExs = 100;
    
    criarNovaSerie eg = new criarNovaSerie();
    ListadorTodos lt = new ListadorTodos();

    Professor(){
    	Treino[] treino_teste = new Treino[3];
		treino_teste[0] = new Treino(new Exercicio[]{
				new Exercicio("Agachamento", "5", "5"),
				new Exercicio("Desenvolvimento", "5", "5"),
				new Exercicio("Levantamento Terra", "5", "5"), null, null, null, null, null});
		treino_teste[1] = new Treino (new Exercicio[]{
				new Exercicio("Agachamento", "5", "5"),
				new Exercicio("Supino Reto", "5", "5"),
				new Exercicio("Remada Curvada", "5", "5"), null, null, null, null, null});
		treino_teste[2] = new Treino(new Exercicio[]{null,null, null, null, null, null, null, null});
		alunos[0] = new Aluno("Caio", "Cardoso",treino_teste, "00000001");
		Treino[] treino_teste2 = new Treino[3];
		treino_teste2[0] = new Treino(new Exercicio[]{
				new Exercicio("Agachamento 1", "5", "5"),
				new Exercicio("Desenvolvimento 2", "5", "5"),
				new Exercicio("Levantamento Terra 3", "5", "5"), null, null, null, null, null});
		treino_teste2[1] = new Treino (new Exercicio[]{
				new Exercicio("Agachamento 1", "5", "5"),
				new Exercicio("Supino Reto 2", "5", "5"),
				new Exercicio("Remada Curvada 3", "5", "5"), null, null, null, null, null});
		treino_teste2[2] = new Treino(new Exercicio[]{null,null, null, null, null, null, null, null});
		alunos[1] = new Aluno("Jorge","Amado",treino_teste2, "00000002");
		Treino[] treino_teste3 = new Treino[3];
		treino_teste3[0] = new Treino(new Exercicio[]{
				new Exercicio("Agachamento 12", "5", "5"),
				new Exercicio("Desenvolvimento 22", "5", "5"),
				new Exercicio("Levantamento Terra 32", "5", "5"), null, null, null, null, null});
		treino_teste3[1] = new Treino (new Exercicio[]{
				new Exercicio("Agachamento 12", "5", "5"),
				new Exercicio("Supino Reto 22", "5", "5"),
				new Exercicio("Remada Curvada 32", "5", "5"), null, null, null, null, null});
		treino_teste3[2] = new Treino(new Exercicio[]{null,null, null, null, null, null, null, null});
		alunos[2] = new Aluno("Rosvelter","Da Costa",treino_teste2, "00000003");
		n = 3;
		
    }
    public void addAluno(JFormattedTextField nome, JFormattedTextField sobrenome){
    	  alunos[n] = this.retornaNovoAluno(nome,sobrenome);
    	    n = n + 1;
    	  for(int i = 0; i < n;i++){
    		  alunos[i].imprimirNomeP();
    	  }
    }

	void removeAluno() {
		removeAluno(indexOf(alunos[mat_selecionada]));
	}
	private void removeAluno(int k) {
		if (k < 0) return;
		n = n - 1;
		alunos[k] = alunos[n];
		return;
	}
	private int indexOf(Aluno x) {
		for(int i = 0; i < n; i++) {
			if(alunos[i] == x) return i;
		}
		return -1;
	}

       void imprimirAlunos(){
    	for(int i = 0; i < n;i++){
    		    alunos[i].imprimirNomeP();
    	   }
      }
       
	  public void listarAlunos(DefaultListModel<String> listModel){
		  for(int i = 0; i < n; i++) {
			  alunos[i].Listar(listModel, lt);
		  }
	  }
	public void listarAlunosPorNome(DefaultListModel<String> listModel, String nomeDesejado){
		for(int i = 0; i < n; i++) {
			alunos[i].ListarPorNome(listModel, lt, nomeDesejado);
		}
	}
      private Aluno retornaNovoAluno(JFormattedTextField nome, JFormattedTextField sobrenome){
    	  String addNome, addSobrenome, addMatricula;
    	  addNome = nome.getText();
    	  addSobrenome = sobrenome.getText();
		  Random mat = new Random();
		  int n = 10000000 + mat.nextInt(89999999);
		  String matricula = String.valueOf(n);
    	  
    	  
    	  Aluno x = new Aluno(addNome,addSobrenome,new Treino[]{new Treino(new Exercicio[qtsExs]), new Treino(new Exercicio[]{new Exercicio(null,null,null)}), new Treino(new Exercicio[]{new Exercicio(null,null,null)})},matricula);
    	  return x;
      }

      public boolean matriculaExiste(JFormattedTextField x){
    	  String matricula_esc = x.getText();
    	  boolean existe = false;
    	  for(int i = 0; i< n; i++){
    		if(alunos[i].verificarMatricula(x.getText())){
    			existe = true;
    			mat_selecionada = i;
    		}
    	  }
    	  return existe;
      }
      
      public void selecionaMatriculaSelecionada(JFormattedTextField x){
    	  String matricula_esc = x.getText();
    	  for(int i = 0; i< n; i++){
    		if(alunos[i].verificarMatricula(matricula_esc)){
    			mat_selecionada = i;
    		}
    	  }
      }
      
      public void criarNovoExs(JFormattedTextField matricula, JFormattedTextField x_treino,JFormattedTextField qtsExs, JFormattedTextField exs, JFormattedTextField serie, JFormattedTextField repeticoes){
  		selecionaMatriculaSelecionada(matricula);
  		this.qtsExs = Integer.parseInt(qtsExs.getText());
      	if(this.matriculaExiste(matricula) == true){
  			alunos[mat_selecionada].criarNovosExs(x_treino, eg, qtsExs, exs, serie, repeticoes);
      	  }
      	  else{
		  	System.out.println("ERROR");}
      }
      
      public void imprimirDados(JLabel i_nome, JLabel i_matricula ){
    	  alunos[mat_selecionada].mostrarNome(i_nome);
    	  alunos[mat_selecionada].mostrarMatriculaAluno(i_matricula);
      }
      
      public void imprimirTreinoAluno(int posTreino, JFormattedTextField matricula, ImprimirExs imprimir){
    	  alunos[mat_selecionada].imprimirTreinamento(posTreino, imprimir);
      }

      public void reiniciaAddExs(){
      	eg.reUtilizar();
	  }
      
      public void diminuirTreino(JFormattedTextField recebe_treino, JFormattedTextField qtsExs ){
		  alunos[mat_selecionada].diminuirNovoTreino(recebe_treino, qtsExs);
	  }
      
      
      
}