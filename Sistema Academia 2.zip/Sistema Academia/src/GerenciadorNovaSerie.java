import javax.swing.JButton;
import javax.swing.JFormattedTextField;

public interface GerenciadorNovaSerie {
	void criarSerie(Exercicio[] exercicios, JFormattedTextField qtsExs, JFormattedTextField exs, JFormattedTextField serie, JFormattedTextField repeticoes);

	void reUtilizar();

}