import javax.swing.*;
import java.awt.event.*;

public class Agachamento extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JTextPane levanteSeESegureTextPane;

    public Agachamento() {
        setContentPane(contentPane);
        setModal(true);

        buttonOK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        });
    }

    private void onCancel() {
        // add your code here
        dispose();
    }

    public static void main(String[] args) {

        try {
            // Set cross-platform Java L&F (also called "Metal")
            UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName());
        }
        catch (UnsupportedLookAndFeelException e) {
            // handle exception
        }
        catch (ClassNotFoundException e) {
            // handle exception
        }
        catch (InstantiationException e) {
            // handle exception
        }
        catch (IllegalAccessException e) {
            // handle exception
        }

        Agachamento dialog = new Agachamento();
        dialog.pack();
        dialog.setVisible(true);
    }
}
