import javax.swing.*;

/**
 * Created by supervisor on 03/07/17.
 */
public interface Listador {
    void lista(DefaultListModel<String> listModel, String nome, String sobrenome, String matricula);
}
