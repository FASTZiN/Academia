import javax.swing.*;

/**
 * Created by supervisor on 03/07/17.
 */
public class ListadorTodos implements Listador {

    @Override
    public void lista(DefaultListModel<String> listModel, String nome, String sobrenome, String matricula) {
        listModel.addElement("Nome: "+ nome + " Sobrenome: " + sobrenome + " Matricula: "+ matricula);
    }
}
