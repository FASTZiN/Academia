import javax.swing.JFormattedTextField;

/**
 * Created by Marcel Fernandes on 6/2/2017.
 */
public class Treino{
    private int x;
    private int n;
    Exercicio[] exercicios;
    
    Treino(Exercicio[] exercicios){
        this.exercicios = exercicios;
    }
    
    void imprimirTreino(ImprimirExs ge){
    	for(Exercicio e : exercicios){
    	if(e != null)
    		e.imprimir(ge);
    	}
    }
    
    void criarNovosExs(GerenciadorNovaSerie gt, JFormattedTextField qtsExs, JFormattedTextField exs, JFormattedTextField serie, JFormattedTextField repeticoes){
        gt.criarSerie(exercicios,qtsExs, exs, serie, repeticoes);
    }
    void removerUltimosExs(JFormattedTextField qtsExs){
        //Se o novo treino for menor que o treino anterior
        n = exercicios.length;
        x = Integer.parseInt(qtsExs.getText());
        if(x < n){
            for(int i = n - 1; i >= x;i = i - 1) {
                removeAluno(indexOf(exercicios[i]));
            }
         n = x;
        }
    }
    private void removeAluno(int k) {
        if (k < 0) return;
        n = n - 1;
        exercicios[k] = null;
        return;
    }
    private int indexOf(Exercicio x) {
        for(int i = 0; i < n; i++) {
            if(exercicios[i] == x) return i;
        }
        return -1;
    }
 }