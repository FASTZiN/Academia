import javax.swing.JTextArea;

public interface GerenciadorExs {

	void imprimirExs(String nome, String serie, String repeticao);
	
}
