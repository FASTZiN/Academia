
import java.awt.event.ActionListener;

import javax.swing.*;

public class Aluno extends Pessoa{
    private Treino[] treinos = new Treino[3];
    private String matriculaAluno;
    
    public Aluno(String nome,String sobrenome,Treino[] treinos, String matriculaAluno) {
    	super(nome, sobrenome);
        this.treinos = treinos;
        this.matriculaAluno = matriculaAluno;
    }

    public void mostrarNome(JLabel r) {
        r.setText("Nome: "+ nome + " "+ sobrenome);
    }

    public void mostrarMatriculaAluno(JLabel r) {
        r.setText("Matricula: "+ matriculaAluno);
    }

    public void imprimirNomeP(){
    	System.out.println(nome + "/"+ matriculaAluno);
    }
    
    public boolean verificarMatricula(String matricula){
    	boolean res = false;
    	if (this.matriculaAluno.equals(matricula))
    		res = true;

    	return res;
    }
	public void imprimirTreinamento(int x_treino,ImprimirExs ge){
	treinos[x_treino].imprimirTreino(ge);
	}

	public void criarNovosExs(JFormattedTextField recebe_treino, GerenciadorNovaSerie gt, JFormattedTextField qtsExs, JFormattedTextField exs, JFormattedTextField serie, JFormattedTextField repeticoes){
	    if(recebe_treino.getText().equals("A") || recebe_treino.getText().equals("a")){
            treinos[0].criarNovosExs(gt,qtsExs, exs, serie, repeticoes);
        }
        else if(recebe_treino.getText().equals("B") || recebe_treino.getText().equals("b")){
            treinos[1].criarNovosExs(gt,qtsExs, exs, serie, repeticoes);
        }else if(recebe_treino.getText().equals("B") || recebe_treino.getText().equals("b")){
            treinos[2].criarNovosExs(gt,qtsExs, exs, serie, repeticoes);
        }
	}

	public void diminuirNovoTreino(JFormattedTextField recebe_treino, JFormattedTextField qtsExs){
        if(recebe_treino.getText().equals("A") || recebe_treino.getText().equals("a")){
            treinos[0].removerUltimosExs(qtsExs);
        }
        else if(recebe_treino.getText().equals("B") || recebe_treino.getText().equals("b")){
            treinos[1].removerUltimosExs(qtsExs);
        }else if(recebe_treino.getText().equals("B") || recebe_treino.getText().equals("b")){
            treinos[2].removerUltimosExs(qtsExs);
        }
    }

    public void Listar(DefaultListModel<String> listModel, Listador p){
        p.lista(listModel, nome, sobrenome, matriculaAluno);
    }
    public void ListarPorNome(DefaultListModel<String> listModel, Listador p, String nomeDesejado){
        if(nomeDesejado.equals(nome)){
        p.lista(listModel, nome, sobrenome, matriculaAluno);}
    }
}

