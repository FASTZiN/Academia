import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.*;

public class GUIAjuda extends JDialog {
    private JPanel contentPane;
    private JButton buttonCancel;
    private JList list;
    private JButton OKButton;
    private Agachamento agachamento;
    private SupinoRetoComBarra supinoRetoComBarra;
    private SupinoRetoComHalter supinoRetoComHalter;
    private SupinoInclinado supinoInclinado;
    private SupinoDeclinado supinoDeclinado;
    private Desenvolvimento desenvolvimento;
    private LevantamentoTerra levantamentoTerra;
    private RemadaCurva remadaCurva;
    private RoscaUnilateral roscaUnilateral;
    private Rosca rosca;
    private RoscaInterior roscaInterior;
    private RoscaAlternada roscaAlternada;
    private RoscaMartelo roscaMartelo;
    private LevantamentoLateral levantamentoLateral;
    private LevantamentoDoDeltoideUmBracoInclinado levantamentoDoDeltoideUmBracoInclinado;
    private LevantamentoLateralSentado levantamentoLateralSentado;
    private LevantamentoDoDeltoideTraseiroInclinado levantamentoDoDeltoideTraseiroInclinado;

    public GUIAjuda() {
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(OKButton);
        OKButton.setEnabled(false);

        OKButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onOK();
            }
        });

        buttonCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        list.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (list.getSelectedIndex() == -1) {
                    //No selection, disable fire button.
                    OKButton.setEnabled(false);

                } else {
                    //Selection, enable the fire button.
                    OKButton.setEnabled(true);
                }
            }
        });
    }

    private void onOK() {
        // add your code here
        if (list.getSelectedValue().equals("Agachamento")) {
            agachamento = new Agachamento();
            agachamento.main(null);
        }
        else if (list.getSelectedValue().equals("Supino Reto com Barra")){
            supinoRetoComBarra = new SupinoRetoComBarra();
            supinoRetoComBarra.main(null);
        }
        else if(list.getSelectedValue().equals("Supino Reto com Halter")){
            supinoRetoComHalter = new SupinoRetoComHalter();
            supinoRetoComHalter.main(null);
        }
        else if(list.getSelectedValue().equals("Supino Inclinado")){
            supinoInclinado = new SupinoInclinado();
            supinoInclinado.main(null);
        }
        else if(list.getSelectedValue().equals("Supino Declinado")){
            supinoDeclinado = new SupinoDeclinado();
            supinoDeclinado.main(null);
        }
        else if(list.getSelectedValue().equals("Desenvolvimento")){
            desenvolvimento = new Desenvolvimento();
            desenvolvimento.main(null);
        }
        else if(list.getSelectedValue().equals("Levantamento Terra")){
            levantamentoTerra = new LevantamentoTerra();
            levantamentoTerra.main(null);
        }
        else if(list.getSelectedValue().equals("Remada Curva")){
            remadaCurva = new RemadaCurva();
            remadaCurva.main(null);
        }
        else if(list.getSelectedValue().equals("Rosca Unilateral")){
            roscaUnilateral = new RoscaUnilateral();
            roscaUnilateral.main(null);
        }
        else if (list.getSelectedValue().equals("Rosca")){
            rosca = new Rosca();
            rosca.main(null);
        }
        else if(list.getSelectedValue().equals("Rosca Interior")){
            roscaInterior = new RoscaInterior();
            roscaInterior.main(null);
        }
        else if(list.getSelectedValue().equals("Rosca Alternada")){
            roscaAlternada = new RoscaAlternada();
            roscaAlternada.main(null);
        }
        else if(list.getSelectedValue().equals("Rosca Martelo")){
            roscaMartelo = new RoscaMartelo();
            roscaMartelo.main(null);
        }
        else if(list.getSelectedValue().equals("Levantamento Lateral")){
            levantamentoLateral = new LevantamentoLateral();
            levantamentoLateral.main(null);
        }
        else if(list.getSelectedValue().equals("Levantamento do Deltóide, Um Braço, Inclinado")){
            levantamentoDoDeltoideUmBracoInclinado = new LevantamentoDoDeltoideUmBracoInclinado();
            levantamentoDoDeltoideUmBracoInclinado.main(null);
        }
        else if(list.getSelectedValue().equals("Levantamento Lateral, Sentado")){
            levantamentoLateralSentado = new LevantamentoLateralSentado();
            levantamentoLateralSentado.main(null);
        }
        else if(list.getSelectedValue().equals("Levantamento do Deltóide Traseiro, Inclianado")){
            levantamentoDoDeltoideTraseiroInclinado = new LevantamentoDoDeltoideTraseiroInclinado();
            levantamentoDoDeltoideTraseiroInclinado.main(null);
        }

    }

    private void onCancel() {
        // add your code here if necessary
        dispose();
    }

    public static void main(String[] args) {

        try {
            // Set cross-platform Java L&F (also called "Metal")
            UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName());
        }
        catch (UnsupportedLookAndFeelException e) {
            // handle exception
        }
        catch (ClassNotFoundException e) {
            // handle exception
        }
        catch (InstantiationException e) {
            // handle exception
        }
        catch (IllegalAccessException e) {
            // handle exception
        }

        GUIAjuda dialog = new GUIAjuda();
        dialog.pack();
        dialog.setVisible(true);
    }
}
