import javax.swing.JTextArea;

public interface GerenciadorTreino {
	
	public void imprimirTreino(Exercicio[] exercicios);
	
	
}
