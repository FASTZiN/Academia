
public class Pessoa {
protected String nome;

		Pessoa(String nome){
			this.nome = nome;
		}

}
