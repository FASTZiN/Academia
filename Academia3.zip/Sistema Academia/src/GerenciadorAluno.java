
public interface GerenciadorAluno {

}
